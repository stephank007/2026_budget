import pandas as pd
from pathlib import Path
import warnings
from rich.console import Console
from rich.table import Table

console = Console(force_terminal=True, color_system="truecolor")
warnings.filterwarnings(
    "ignore",
    message="Workbook contains no default style",
    category=UserWarning,
    module="openpyxl"
)

merged = pd.read_excel("../processed/merged_one_sheet.xlsx", sheet_name="Merged")

# Convert mm.yy → pandas datetime
merged['date_mm_yy'] = pd.to_datetime(merged['date'], format='%d.%m.%y', errors='coerce')

# Extract month + year for easy matching
merged['m_month'] = merged['date_mm_yy'].dt.month
merged['m_year' ] = merged['date_mm_yy'].dt.year
#

sheet_name  = "Income"   # e.g. "Sheet1"
column_name = "amount"   # e.g. "Amount"
total = 0

results = []
for file in Path("./").glob("*.xlsx"):
    if file.name.startswith("~$"):   # skip temp Excel files
        continue
    
    try:
        xls = pd.ExcelFile(file)
    except Exception as e:
        print(f"Could not open {file.name}: {e}")
        continue
    
    # Skip if the sheet is missing
    if sheet_name not in xls.sheet_names:
        # print(f"Skipping {file.name}: sheet '{sheet_name}' not found")
        continue
    
    try:
        df = pd.read_excel(xls, sheet_name=sheet_name, usecols=[column_name])
        df = pd.read_excel(xls, sheet_name=sheet_name)
        df['date_mm_yy'] = pd.to_datetime(df['date'], format='%d.%m.%y', errors='coerce')
       
        # Extract month + year for easy matching
        selected_mm = df['date_mm_yy'].dt.month.dropna().unique()[0]
        selected_yy = df['date_mm_yy'].dt.year .dropna().unique()[0]
        #
        expenses    = merged.loc[(merged['m_month'] == selected_mm) & (merged['m_year'] == selected_yy)]
        expenses    = expenses['expense'].sum()
        
        income = pd.to_numeric(df[column_name], errors="coerce").sum()
        diff   = income - expenses
        results.append((file, income, expenses, diff))
        total  += pd.to_numeric(df[column_name], errors="coerce").sum()
        # print(f"Total: {file}: {total:,.2f}")
    except Exception as e:
        print(f"Problem reading '{column_name}' in {file.name}: {e}")
        
        
# -------- PRINT RICH TABLE --------
print()
table = Table(title="Monthly Income vs Expenses")

table.add_column("File"    , justify="center", header_style="bold", style="")
table.add_column("Income"  , justify="right" , header_style="bold", style="")
table.add_column("Expenses", justify="right" , header_style="bold")
table.add_column("Net"     , justify="center", header_style="bold")

for file, m_total, exp_sum, diff in results:
    color = "green" if diff >= 0 else "red"
    table.add_row(
        str(file),
        f"{m_total:,.2f}",
        f"{exp_sum:,.2f}",
        f"[{color}]{diff:,.2f}[/{color}]"
    )

table.add_row("", "", "", "")
# ---- GRAND TOTAL ROW ----
grand_income = sum(r[1] for r in results)
grand_exp    = sum(r[2] for r in results)
grand_diff   = grand_income - grand_exp

grand_color = "green" if grand_diff >= 0 else "red"

table.add_row(
    "[bold]GRAND TOTAL[/bold]",
    f"[bold]{grand_income:,.2f}[/bold]",
    f"[bold]{grand_exp:,.2f}[/bold]",
    f"[bold {grand_color}]{grand_diff:,.2f}[/bold {grand_color}]",
)

console.print(table, justify="center")

# print(f"Grand Total: {total:,.2f}")
